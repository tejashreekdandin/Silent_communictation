function send(code) {
  const id = document.getElementById("fid").value;
  if (!id) {
    alert("Please enter Firefighter ID");
    return;
  }

  fetch("http://localhost:9090/send?id=" + id + "&code=" + code)
    .then(res => res.text())
    .then(data => {
      document.getElementById("chatBox").textContent = data;
    });
}

// Auto refresh messages every 2 seconds
setInterval(() => {
  fetch("http://localhost:9090/messages")
    .then(res => res.text())
    .then(data => {
      document.getElementById("chatBox").textContent = data;
    });
}, 2000);

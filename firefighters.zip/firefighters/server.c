#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winsock2.h>

#pragma comment(lib, "ws2_32.lib")

#define PORT 9090

void handle_client(SOCKET client_socket);
void send_response(SOCKET client_socket, const char *content);
const char* decode(int code);

int main() {
    WSADATA wsa;
    SOCKET server_fd, client_socket;
    struct sockaddr_in address;
    int addrlen = sizeof(address);

    WSAStartup(MAKEWORD(2,2), &wsa);

    server_fd = socket(AF_INET, SOCK_STREAM, 0);

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    bind(server_fd, (struct sockaddr *)&address, sizeof(address));
    listen(server_fd, 5);

    printf("🔥 Silent Communication Server running on http://localhost:%d\n", PORT);

    while (1) {
        client_socket = accept(server_fd, (struct sockaddr *)&address, &addrlen);
        handle_client(client_socket);
        closesocket(client_socket);
    }

    WSACleanup();
    return 0;
}

void handle_client(SOCKET client_socket) {
    char buffer[4096] = {0};
    recv(client_socket, buffer, sizeof(buffer), 0);

    static char messageLog[8192] = "";

    if (strstr(buffer, "GET /send")) {
        int id = 0, code = 0;
        sscanf(buffer, "GET /send?id=%d&code=%d", &id, &code);

        char newMessage[200];
        sprintf(newMessage, "Firefighter %d: %s\n", id, decode(code));
        strcat(messageLog, newMessage);
    }

    send_response(client_socket, messageLog);
}

void send_response(SOCKET client_socket, const char *content) {
    char header[8192];
    sprintf(header,
            "HTTP/1.1 200 OK\r\n"
            "Content-Type: text/plain\r\n"
            "Access-Control-Allow-Origin: *\r\n"
            "Content-Length: %d\r\n\r\n%s",
            (int)strlen(content), content);

    send(client_socket, header, strlen(header), 0);
}

const char* decode(int code) {
    switch(code) {
        case 1: return "Move Forward";
        case 2: return "Danger Ahead";
        case 3: return "Need Help";
        case 4: return "Victim Found";
        case 5: return "Retreat Immediately";
        default: return "Invalid Code";
    }
}
